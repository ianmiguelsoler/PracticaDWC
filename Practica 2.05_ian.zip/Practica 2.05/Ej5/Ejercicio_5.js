"use strict";

import { calculaNumeroDni } from "../Biblioteca_JS/funciones.js";


//!Ejercicio 5.
//?Solución:
calculaNumeroDni()


