"use strict";

import { solicitarDni } from "../Biblioteca_JS/funciones.js";


//!Ejercicio 3.
//?Solución:
solicitarDni()


