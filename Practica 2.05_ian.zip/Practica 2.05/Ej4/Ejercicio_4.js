"use strict";

import { mostrarFecha } from "../Biblioteca_JS/funciones.js";


//!Ejercicio 4.
//?Solución:
mostrarFecha()


