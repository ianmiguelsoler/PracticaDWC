"use strict";

import { temporizador } from "../Biblioteca_JS/funciones.js";


//!Ejercicio 2.
//*Variables
let minutos = 2;
let segundos = 40;

//?Solución:
console.log("El temporizador se mostrará a continuación:")
//LLamamos a la función js.
temporizador(minutos, segundos)


