"use strict";

import { cadenaCani } from "../Biblioteca_JS/funciones.js";

//!Ejercicio 2.
//?Solución:
const cani = cadenaCani("Pedro es un cani y lo sabes");
console.log("Su cadena de texto se ha vuelto cani, te lo muestro a continuación:\n", cani);

