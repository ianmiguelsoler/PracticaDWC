"use strict";

import { calculaNumerosPrimos } from "../Biblioteca_JS/funciones.js";


//!Ejercicio 6.
//?Solución:
calculaNumerosPrimos()


